ALTER TABLE "demo$reportedtemperature" RENAME TO "42f49fad9b754d1d97c238996baf2b73";
DELETE FROM "mendixsystem$entity"  WHERE "id" = '146c3de1-a122-44cd-99c0-5c5c5e47b242';
DELETE FROM "mendixsystem$entityidentifier"  WHERE "id" = '146c3de1-a122-44cd-99c0-5c5c5e47b242';
DELETE FROM "mendixsystem$sequence"  WHERE "attribute_id" IN ( SELECT "id" FROM "mendixsystem$attribute" WHERE "entity_id" = '146c3de1-a122-44cd-99c0-5c5c5e47b242' );
DELETE FROM "mendixsystem$remote_primary_key"  WHERE "entity_id" = '146c3de1-a122-44cd-99c0-5c5c5e47b242';
DELETE FROM "mendixsystem$attribute"  WHERE "entity_id" = '146c3de1-a122-44cd-99c0-5c5c5e47b242';
DROP TABLE "42f49fad9b754d1d97c238996baf2b73";
UPDATE "mendixsystem$version" SET "versionnumber" = '4.2', "lastsyncdate" = '20251222 10:48:48';
