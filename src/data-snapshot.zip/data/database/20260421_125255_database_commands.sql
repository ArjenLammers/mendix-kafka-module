ALTER TABLE "kafka$config" ADD "sasl_login_callback_handler_class" VARCHAR_IGNORECASE(200) NULL;
ALTER TABLE "kafka$config" ADD "sasl_oauthbearer_token_endpoint_url" VARCHAR_IGNORECASE(1024) NULL;
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('88dc39ed-41ba-4c74-a210-d3aeb0b604c2', 'de9e94c0-40ec-4767-9dd8-f7ae69147c41', 'sasl_login_callback_handler_class', 'sasl_login_callback_handler_class', 30, 200, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('2f91e856-e4b9-4ded-84c3-a5318d10f9d5', 'de9e94c0-40ec-4767-9dd8-f7ae69147c41', 'sasl_oauthbearer_token_endpoint_url', 'sasl_oauthbearer_token_endpoint_url', 30, 1024, '', false);
UPDATE "mendixsystem$version" SET "versionnumber" = '4.2', "lastsyncdate" = '20260421 12:52:53';
