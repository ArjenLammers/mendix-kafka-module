ALTER TABLE "system$workflowusertask_assignee" DROP CONSTRAINT "uniq_system$workflowusertask_assignee_system$workflowusertaskid";
DROP INDEX "idx_system$workflowusertask_assignee_system$user_system$workflowusertask";
ALTER TABLE "system$workflowactivity_taskactor" DROP CONSTRAINT "uniq_system$workflowactivity_taskactor_system$workflowactivityid";
DROP INDEX "idx_system$workflowactivity_taskactor_system$user_system$workflowactivity";
ALTER TABLE "system$databrokerentitymetadata" RENAME TO "3a98b470f11d4e54aff2527e9ea57ed3";
ALTER TABLE "system$workflowusertask_assignee" RENAME TO "system$workflowusertask_assignees";
ALTER TABLE "system$workflowactivity_taskactor" RENAME TO "system$workflowactivity_actor";
ALTER TABLE "system$workflow" ADD "canapplyjumpto" BOOLEAN NULL;
UPDATE "system$workflow" SET "canapplyjumpto" = true;
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('986e45cf-3a56-4836-8ece-53df4d3dcf9e', '2ae37bf5-ecb8-4c55-b967-d7383925b208', 'CanApplyJumpTo', 'canapplyjumpto', 10, 0, 'true', false);
ALTER TABLE "system$workflowusertask" ADD "completiontype" VARCHAR_IGNORECASE(9) NULL;
UPDATE "system$workflowusertask" SET "completiontype" = 'Single';
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('7d72fc37-c5cd-425d-82d2-0b8559b28314', '3729d27c-735b-457a-b210-9dffb125c3f3', 'CompletionType', 'completiontype', 40, 9, 'Single', false);
ALTER TABLE "system$image" ADD "enablecaching" BOOLEAN NULL;
UPDATE "system$image" SET "enablecaching" = true;
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('0a5f1064-838e-4b91-a9c3-904428d203d2', '37827192-315d-4ab6-85b8-f626f866ea76', 'EnableCaching', 'enablecaching', 10, 0, 'true', false);
ALTER TABLE "system$workflowdefinition" ADD "islocked" BOOLEAN NULL;
UPDATE "system$workflowdefinition" SET "islocked" = false;
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('5544e32c-48e4-4580-bac2-ed8a14f1e098', '5c570d3b-7b31-44fe-abd6-269a234584c5', 'IsLocked', 'islocked', 10, 0, 'false', false);
ALTER TABLE "system$workflowactivity" DROP COLUMN "ismigrationactivity";
ALTER TABLE "system$workflowactivity" ALTER COLUMN "error" RENAME TO "reason";
ALTER TABLE "system$workflowactivity" ADD "actiontime" TIMESTAMP NULL;
ALTER TABLE "system$workflowactivity" ADD "detailsjson" VARCHAR_IGNORECASE(2147483647) NULL;
DELETE FROM "mendixsystem$attribute"  WHERE "id" = 'd78085f1-fdf5-40c1-93ae-30de543e4b81';
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('f3e0983a-dbe5-4287-af2d-9f455e847851', 'a5952592-bb2c-4798-9805-f9ff91ad97de', 'DetailsJson', 'detailsjson', 30, 0, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('431cc58a-fc36-427b-82e5-0751fc5fce22', 'a5952592-bb2c-4798-9805-f9ff91ad97de', 'ActionTime', 'actiontime', 20, 0, '', false);
UPDATE "mendixsystem$attribute" SET "entity_id" = 'a5952592-bb2c-4798-9805-f9ff91ad97de', "attribute_name" = 'Reason', "column_name" = 'reason', "type" = 30, "length" = 0, "default_value" = '', "is_auto_number" = false WHERE "id" = '3b8d6bea-dfb5-497b-b2ad-c423efbd66eb';
DELETE FROM "mendixsystem$entity"  WHERE "id" = 'df86cd1e-f9ac-42d4-bcd0-a185540a247a';
DELETE FROM "mendixsystem$entityidentifier"  WHERE "id" = 'df86cd1e-f9ac-42d4-bcd0-a185540a247a';
DELETE FROM "mendixsystem$sequence"  WHERE "attribute_id" IN ( SELECT "id" FROM "mendixsystem$attribute" WHERE "entity_id" = 'df86cd1e-f9ac-42d4-bcd0-a185540a247a' );
DELETE FROM "mendixsystem$remote_primary_key"  WHERE "entity_id" = 'df86cd1e-f9ac-42d4-bcd0-a185540a247a';
DELETE FROM "mendixsystem$attribute"  WHERE "entity_id" = 'df86cd1e-f9ac-42d4-bcd0-a185540a247a';
CREATE TABLE "system$workflowactivityusertaskoutcome" (
	"id" BIGINT NOT NULL,
	"outcome" VARCHAR_IGNORECASE(200) NULL,
	"time" TIMESTAMP NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", "entity_name", "table_name", "remote", "remote_primary_key") VALUES ('1ebda4ad-6e00-4b19-8b95-6b6261beb937', 'System.WorkflowActivityUserTaskOutcome', 'system$workflowactivityusertaskoutcome', false, false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('f854eb95-236e-4c3f-af60-0d72c0cbf27b', '1ebda4ad-6e00-4b19-8b95-6b6261beb937', 'Outcome', 'outcome', 30, 200, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('9c9b1db9-e8ff-4192-b11d-4127162aa51a', '1ebda4ad-6e00-4b19-8b95-6b6261beb937', 'Time', 'time', 20, 0, '', false);
CREATE TABLE "system$workflowusertaskoutcome" (
	"id" BIGINT NOT NULL,
	"outcome" VARCHAR_IGNORECASE(200) NULL,
	"time" TIMESTAMP NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", "entity_name", "table_name", "remote", "remote_primary_key") VALUES ('d753ad05-63c3-4d18-9424-1dd97c7d1a05', 'System.WorkflowUserTaskOutcome', 'system$workflowusertaskoutcome', false, false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('1c43b5b0-f645-4bc1-83fe-2da08ef1eba4', 'd753ad05-63c3-4d18-9424-1dd97c7d1a05', 'Outcome', 'outcome', 30, 200, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('2b63667d-dda0-4033-b432-679f51187ebb', 'd753ad05-63c3-4d18-9424-1dd97c7d1a05', 'Time', 'time', 20, 0, '', false);
CREATE INDEX "idx_system$workflowusertask_assignees_system$user_system$workflowusertask" ON "system$workflowusertask_assignees" ("system$userid" ASC,"system$workflowusertaskid" ASC);
DELETE FROM "mendixsystem$unique_constraint"  WHERE "name" = 'uniq_system$workflowusertask_assignee_system$workflowusertaskid' AND "column_id" = 'ed895e88-8fb4-3df0-b86f-faab883d19ec';
UPDATE "mendixsystem$association" SET "association_name" = 'System.WorkflowUserTask_Assignees', "table_name" = 'system$workflowusertask_assignees', "parent_entity_id" = '3729d27c-735b-457a-b210-9dffb125c3f3', "child_entity_id" = '282e2e60-88a5-469d-84a5-ba8d9151644f', "parent_column_name" = 'system$workflowusertaskid', "child_column_name" = 'system$userid', "pk_index_name" = NULL, "index_name" = 'idx_system$workflowusertask_assignees_system$user_system$workflowusertask', "parent_fkc_name" = NULL, "child_fkc_name" = NULL, "parent_fkc_action" = NULL, "child_fkc_action" = NULL, "storage_format" = 2 WHERE "id" = '929fbbed-d3a8-4ea2-b6ad-b28de4f77776';
CREATE INDEX "idx_system$workflowactivity_actor_system$user_system$workflowactivity" ON "system$workflowactivity_actor" ("system$userid" ASC,"system$workflowactivityid" ASC);
ALTER TABLE "system$workflowactivity_actor" ADD CONSTRAINT "uniq_system$workflowactivity_actor_system$workflowactivityid" UNIQUE ("system$workflowactivityid");
DELETE FROM "mendixsystem$unique_constraint"  WHERE "name" = 'uniq_system$workflowactivity_taskactor_system$workflowactivityid' AND "column_id" = '38f7a539-d2df-398f-99b4-047c6f7ff859';
INSERT INTO "mendixsystem$unique_constraint" ("name", "table_id", "column_id") VALUES ('uniq_system$workflowactivity_actor_system$workflowactivityid', '63446029-b863-4c07-ab91-22219be89b70', '38f7a539-d2df-398f-99b4-047c6f7ff859');
UPDATE "mendixsystem$association" SET "association_name" = 'System.WorkflowActivity_Actor', "table_name" = 'system$workflowactivity_actor', "parent_entity_id" = 'a5952592-bb2c-4798-9805-f9ff91ad97de', "child_entity_id" = '282e2e60-88a5-469d-84a5-ba8d9151644f', "parent_column_name" = 'system$workflowactivityid', "child_column_name" = 'system$userid', "pk_index_name" = NULL, "index_name" = 'idx_system$workflowactivity_actor_system$user_system$workflowactivity', "parent_fkc_name" = NULL, "child_fkc_name" = NULL, "parent_fkc_action" = NULL, "child_fkc_action" = NULL, "storage_format" = 2 WHERE "id" = '63446029-b863-4c07-ab91-22219be89b70';
CREATE TABLE "system$workflowactivityusertaskoutcome_workflowactivity" (
	"system$workflowactivityusertaskoutcomeid" BIGINT NOT NULL,
	"system$workflowactivityid" BIGINT NOT NULL,
	PRIMARY KEY("system$workflowactivityusertaskoutcomeid","system$workflowactivityid"),
	CONSTRAINT "uniq_system$workflowactivityusertaskoutcome_workflowactivity_system$workflowactivityusertaskoutcomeid" UNIQUE ("system$workflowactivityusertaskoutcomeid"));
CREATE INDEX "idx_system$workflowactivityusertaskoutcome_workflowactivity_system$workflowactivity_system$workflowactivityusertaskoutcome" ON "system$workflowactivityusertaskoutcome_workflowactivity" ("system$workflowactivityid" ASC,"system$workflowactivityusertaskoutcomeid" ASC);
INSERT INTO "mendixsystem$association" ("id", "association_name", "table_name", "parent_entity_id", "child_entity_id", "parent_column_name", "child_column_name", "index_name", "storage_format") VALUES ('9ce50251-ec5a-46d0-ba7e-cb91876078f0', 'System.WorkflowActivityUserTaskOutcome_WorkflowActivity', 'system$workflowactivityusertaskoutcome_workflowactivity', '1ebda4ad-6e00-4b19-8b95-6b6261beb937', 'a5952592-bb2c-4798-9805-f9ff91ad97de', 'system$workflowactivityusertaskoutcomeid', 'system$workflowactivityid', 'idx_system$workflowactivityusertaskoutcome_workflowactivity_system$workflowactivity_system$workflowactivityusertaskoutcome', 2);
INSERT INTO "mendixsystem$unique_constraint" ("name", "table_id", "column_id") VALUES ('uniq_system$workflowactivityusertaskoutcome_workflowactivity_system$workflowactivityusertaskoutcomeid', '9ce50251-ec5a-46d0-ba7e-cb91876078f0', 'ced1f439-bb5d-34eb-9344-68a02c7877e7');
CREATE TABLE "system$workflowactivityusertaskoutcome_user" (
	"system$workflowactivityusertaskoutcomeid" BIGINT NOT NULL,
	"system$userid" BIGINT NOT NULL,
	PRIMARY KEY("system$workflowactivityusertaskoutcomeid","system$userid"),
	CONSTRAINT "uniq_system$workflowactivityusertaskoutcome_user_system$workflowactivityusertaskoutcomeid" UNIQUE ("system$workflowactivityusertaskoutcomeid"));
CREATE INDEX "idx_system$workflowactivityusertaskoutcome_user_system$user_system$workflowactivityusertaskoutcome" ON "system$workflowactivityusertaskoutcome_user" ("system$userid" ASC,"system$workflowactivityusertaskoutcomeid" ASC);
INSERT INTO "mendixsystem$association" ("id", "association_name", "table_name", "parent_entity_id", "child_entity_id", "parent_column_name", "child_column_name", "index_name", "storage_format") VALUES ('69f85619-f30b-427c-adb1-7be7ce8cc3dd', 'System.WorkflowActivityUserTaskOutcome_User', 'system$workflowactivityusertaskoutcome_user', '1ebda4ad-6e00-4b19-8b95-6b6261beb937', '282e2e60-88a5-469d-84a5-ba8d9151644f', 'system$workflowactivityusertaskoutcomeid', 'system$userid', 'idx_system$workflowactivityusertaskoutcome_user_system$user_system$workflowactivityusertaskoutcome', 2);
INSERT INTO "mendixsystem$unique_constraint" ("name", "table_id", "column_id") VALUES ('uniq_system$workflowactivityusertaskoutcome_user_system$workflowactivityusertaskoutcomeid', '69f85619-f30b-427c-adb1-7be7ce8cc3dd', '0e354480-b4c1-3655-9f12-e34dc1488c2f');
CREATE TABLE "system$workflowusertaskoutcome_user" (
	"system$workflowusertaskoutcomeid" BIGINT NOT NULL,
	"system$userid" BIGINT NOT NULL,
	PRIMARY KEY("system$workflowusertaskoutcomeid","system$userid"),
	CONSTRAINT "uniq_system$workflowusertaskoutcome_user_system$workflowusertaskoutcomeid" UNIQUE ("system$workflowusertaskoutcomeid"));
CREATE INDEX "idx_system$workflowusertaskoutcome_user_system$user_system$workflowusertaskoutcome" ON "system$workflowusertaskoutcome_user" ("system$userid" ASC,"system$workflowusertaskoutcomeid" ASC);
INSERT INTO "mendixsystem$association" ("id", "association_name", "table_name", "parent_entity_id", "child_entity_id", "parent_column_name", "child_column_name", "index_name", "storage_format") VALUES ('d49ae7eb-5886-4a82-8659-be0b01d13104', 'System.WorkflowUserTaskOutcome_User', 'system$workflowusertaskoutcome_user', 'd753ad05-63c3-4d18-9424-1dd97c7d1a05', '282e2e60-88a5-469d-84a5-ba8d9151644f', 'system$workflowusertaskoutcomeid', 'system$userid', 'idx_system$workflowusertaskoutcome_user_system$user_system$workflowusertaskoutcome', 2);
INSERT INTO "mendixsystem$unique_constraint" ("name", "table_id", "column_id") VALUES ('uniq_system$workflowusertaskoutcome_user_system$workflowusertaskoutcomeid', 'd49ae7eb-5886-4a82-8659-be0b01d13104', '1416fe96-0847-37c7-8af0-e159dca1b3c7');
CREATE TABLE "system$workflowusertaskoutcome_workflowusertask" (
	"system$workflowusertaskoutcomeid" BIGINT NOT NULL,
	"system$workflowusertaskid" BIGINT NOT NULL,
	PRIMARY KEY("system$workflowusertaskoutcomeid","system$workflowusertaskid"),
	CONSTRAINT "uniq_system$workflowusertaskoutcome_workflowusertask_system$workflowusertaskoutcomeid" UNIQUE ("system$workflowusertaskoutcomeid"));
CREATE INDEX "idx_system$workflowusertaskoutcome_workflowusertask_system$workflowusertask_system$workflowusertaskoutcome" ON "system$workflowusertaskoutcome_workflowusertask" ("system$workflowusertaskid" ASC,"system$workflowusertaskoutcomeid" ASC);
INSERT INTO "mendixsystem$association" ("id", "association_name", "table_name", "parent_entity_id", "child_entity_id", "parent_column_name", "child_column_name", "index_name", "storage_format") VALUES ('37818a79-121d-447e-aa9d-89e88b145180', 'System.WorkflowUserTaskOutcome_WorkflowUserTask', 'system$workflowusertaskoutcome_workflowusertask', 'd753ad05-63c3-4d18-9424-1dd97c7d1a05', '3729d27c-735b-457a-b210-9dffb125c3f3', 'system$workflowusertaskoutcomeid', 'system$workflowusertaskid', 'idx_system$workflowusertaskoutcome_workflowusertask_system$workflowusertask_system$workflowusertaskoutcome', 2);
INSERT INTO "mendixsystem$unique_constraint" ("name", "table_id", "column_id") VALUES ('uniq_system$workflowusertaskoutcome_workflowusertask_system$workflowusertaskoutcomeid', '37818a79-121d-447e-aa9d-89e88b145180', '350d214b-6b9c-3c5d-a6d2-3483fecc59d8');
CREATE TABLE "system$workflow_parentworkflow" (
	"system$workflowid1" BIGINT NOT NULL,
	"system$workflowid2" BIGINT NOT NULL,
	PRIMARY KEY("system$workflowid1","system$workflowid2"),
	CONSTRAINT "uniq_system$workflow_parentworkflow_system$workflowid1" UNIQUE ("system$workflowid1"));
CREATE INDEX "idx_system$workflow_parentworkflow_system$workflow_system$workflow" ON "system$workflow_parentworkflow" ("system$workflowid2" ASC,"system$workflowid1" ASC);
INSERT INTO "mendixsystem$association" ("id", "association_name", "table_name", "parent_entity_id", "child_entity_id", "parent_column_name", "child_column_name", "index_name", "storage_format") VALUES ('79314052-9dcc-47e5-954b-80ec631ddd41', 'System.Workflow_ParentWorkflow', 'system$workflow_parentworkflow', '2ae37bf5-ecb8-4c55-b967-d7383925b208', '2ae37bf5-ecb8-4c55-b967-d7383925b208', 'system$workflowid1', 'system$workflowid2', 'idx_system$workflow_parentworkflow_system$workflow_system$workflow', 2);
INSERT INTO "mendixsystem$unique_constraint" ("name", "table_id", "column_id") VALUES ('uniq_system$workflow_parentworkflow_system$workflowid1', '79314052-9dcc-47e5-954b-80ec631ddd41', '84b93b3b-9d0a-342e-b78b-17657b92fc22');
CREATE TABLE "system$workflowactivity_subworkflow" (
	"system$workflowactivityid" BIGINT NOT NULL,
	"system$workflowid" BIGINT NOT NULL,
	PRIMARY KEY("system$workflowactivityid","system$workflowid"),
	CONSTRAINT "uniq_system$workflowactivity_subworkflow_system$workflowactivityid" UNIQUE ("system$workflowactivityid"));
CREATE INDEX "idx_system$workflowactivity_subworkflow_system$workflow_system$workflowactivity" ON "system$workflowactivity_subworkflow" ("system$workflowid" ASC,"system$workflowactivityid" ASC);
INSERT INTO "mendixsystem$association" ("id", "association_name", "table_name", "parent_entity_id", "child_entity_id", "parent_column_name", "child_column_name", "index_name", "storage_format") VALUES ('5c89ec5d-0378-4afd-afd4-0e7a9fde45a9', 'System.WorkflowActivity_SubWorkflow', 'system$workflowactivity_subworkflow', 'a5952592-bb2c-4798-9805-f9ff91ad97de', '2ae37bf5-ecb8-4c55-b967-d7383925b208', 'system$workflowactivityid', 'system$workflowid', 'idx_system$workflowactivity_subworkflow_system$workflow_system$workflowactivity', 2);
INSERT INTO "mendixsystem$unique_constraint" ("name", "table_id", "column_id") VALUES ('uniq_system$workflowactivity_subworkflow_system$workflowactivityid', '5c89ec5d-0378-4afd-afd4-0e7a9fde45a9', '2d65cc25-b704-3604-8f2b-e3c73d37fb2b');
DROP TABLE "3a98b470f11d4e54aff2527e9ea57ed3";
UPDATE "mendixsystem$version" SET "versionnumber" = '4.2', "lastsyncdate" = '20251219 14:56:21';
