CREATE TABLE "tests$header" (
	"id" BIGINT NOT NULL,
	"key" VARCHAR_IGNORECASE(2147483647) NULL,
	"value" VARCHAR_IGNORECASE(2147483647) NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", "entity_name", "table_name", "remote", "remote_primary_key") VALUES ('d6d76584-9f48-4e54-8978-9ed65a973fbe', 'Tests.Header', 'tests$header', false, false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('800b5f35-e09d-4291-ac56-dca7351ed05c', 'd6d76584-9f48-4e54-8978-9ed65a973fbe', 'Key', 'key', 30, 0, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('c91866f2-a528-4b45-bbca-d7f7a6ab5179', 'd6d76584-9f48-4e54-8978-9ed65a973fbe', 'Value', 'value', 30, 0, '', false);
CREATE TABLE "unittesting$assertionactivity" (
	"id" BIGINT NOT NULL,
	"name" VARCHAR_IGNORECASE(200) NULL,
	"result" VARCHAR_IGNORECASE(10) NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", "entity_name", "table_name", "superentity_id", "remote", "remote_primary_key") VALUES ('bd6ccff6-843f-4be5-84a2-e527f05ac2ca', 'UnitTesting.AssertionActivity', 'unittesting$assertionactivity', '9985e0a6-55b9-45d8-bf2f-39236459e6a1', false, false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('0564ee9f-e9f8-4942-ba44-3021ec67750e', 'bd6ccff6-843f-4be5-84a2-e527f05ac2ca', 'Name', 'name', 30, 200, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('c7970a63-c872-4801-a918-6619c20941d8', 'bd6ccff6-843f-4be5-84a2-e527f05ac2ca', 'Result', 'result', 40, 10, '', false);
CREATE TABLE "unittesting$testsuite" (
	"id" BIGINT NOT NULL,
	"module" VARCHAR_IGNORECASE(255) NULL,
	"lastrun" TIMESTAMP NULL,
	"lastruntime" BIGINT NULL,
	"testcount" BIGINT NULL,
	"testpassedcount" BIGINT NULL,
	"testfailedcount" BIGINT NULL,
	"hassetup" BOOLEAN NULL,
	"hasteardown" BOOLEAN NULL,
	"autorollbackmfs" BOOLEAN NULL,
	"result" VARCHAR_IGNORECASE(10) NULL,
	"prefix1" VARCHAR_IGNORECASE(10) NULL,
	"prefix2" VARCHAR_IGNORECASE(10) NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", "entity_name", "table_name", "remote", "remote_primary_key") VALUES ('496620d8-ac56-4268-be5f-922cab7c3481', 'UnitTesting.TestSuite', 'unittesting$testsuite', false, false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('3e9130b3-0d5a-4550-98ce-41455937c8f7', '496620d8-ac56-4268-be5f-922cab7c3481', 'Module', 'module', 30, 255, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('8de071b4-4a71-4b38-a2b7-0b9840c9f5cb', '496620d8-ac56-4268-be5f-922cab7c3481', 'LastRun', 'lastrun', 20, 0, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('7d82150c-9bce-4ddd-90e4-4eec0d6b5657', '496620d8-ac56-4268-be5f-922cab7c3481', 'LastRunTime', 'lastruntime', 4, 0, '0', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('2631ec21-1129-4890-b721-8af499ef71d3', '496620d8-ac56-4268-be5f-922cab7c3481', 'TestCount', 'testcount', 4, 0, '0', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('a9476eb1-a246-4bea-bbc9-ac5bc95a5e1f', '496620d8-ac56-4268-be5f-922cab7c3481', 'TestPassedCount', 'testpassedcount', 4, 0, '0', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('e344c0f8-e846-4ce9-9847-3032c115b469', '496620d8-ac56-4268-be5f-922cab7c3481', 'TestFailedCount', 'testfailedcount', 4, 0, '0', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('5d545efc-c9c1-469f-878d-9a4af07820e7', '496620d8-ac56-4268-be5f-922cab7c3481', 'HasSetup', 'hassetup', 10, 0, 'false', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('0860aeeb-b32b-4ae7-a0d5-d2f759c6337b', '496620d8-ac56-4268-be5f-922cab7c3481', 'HasTearDown', 'hasteardown', 10, 0, 'false', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('7efa3afb-b512-448a-934a-200a8263cb5e', '496620d8-ac56-4268-be5f-922cab7c3481', 'AutoRollbackMFs', 'autorollbackmfs', 10, 0, 'true', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('887864c4-fa34-44f4-b864-73318642f5f8', '496620d8-ac56-4268-be5f-922cab7c3481', 'Result', 'result', 40, 10, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('f98748dc-51d1-4cd0-b0cf-02e382ed5de7', '496620d8-ac56-4268-be5f-922cab7c3481', 'Prefix1', 'prefix1', 30, 10, 'Test_', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('8aa3ae5a-646b-4e22-a648-d3ed209f09b8', '496620d8-ac56-4268-be5f-922cab7c3481', 'Prefix2', 'prefix2', 30, 10, 'UT_', false);
CREATE TABLE "unittesting$stepactivity" (
	"id" BIGINT NOT NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", "entity_name", "table_name", "superentity_id", "remote", "remote_primary_key") VALUES ('003d4954-7de2-4983-8e03-2c8e07dabe07', 'UnitTesting.StepActivity', 'unittesting$stepactivity', '9985e0a6-55b9-45d8-bf2f-39236459e6a1', false, false);
CREATE TABLE "unittesting$endactivity" (
	"id" BIGINT NOT NULL,
	"result" VARCHAR_IGNORECASE(10) NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", "entity_name", "table_name", "superentity_id", "remote", "remote_primary_key") VALUES ('a146669e-e059-42e7-8b10-2d91317b62f3', 'UnitTesting.EndActivity', 'unittesting$endactivity', '9985e0a6-55b9-45d8-bf2f-39236459e6a1', false, false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('eccb92b9-5efd-4b7e-9277-50593bffbd71', 'a146669e-e059-42e7-8b10-2d91317b62f3', 'Result', 'result', 40, 10, '', false);
CREATE TABLE "tests$message" (
	"id" BIGINT NOT NULL,
	"reference" VARCHAR_IGNORECASE(200) NULL,
	"topic" VARCHAR_IGNORECASE(200) NULL,
	"payload" VARCHAR_IGNORECASE(200) NULL,
	"partition" INT NULL,
	"offset" BIGINT NULL,
	"changeddate" TIMESTAMP NULL,
	PRIMARY KEY("id"));
CREATE INDEX "idx_tests$message_changeddate_asc" ON "tests$message" ("changeddate" ASC,"id" ASC);
CREATE INDEX "idx_tests$message_reference_asc" ON "tests$message" ("reference" ASC,"id" ASC);
INSERT INTO "mendixsystem$entity" ("id", "entity_name", "table_name", "remote", "remote_primary_key") VALUES ('3d4c0596-4d81-4dbd-ab02-cc9679a74705', 'Tests.Message', 'tests$message', false, false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('e90bf2ef-1ebf-4dc5-b464-24a8c9fc9e39', '3d4c0596-4d81-4dbd-ab02-cc9679a74705', 'Reference', 'reference', 30, 200, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('6d58da38-9d9e-47d6-8293-4402ab83911c', '3d4c0596-4d81-4dbd-ab02-cc9679a74705', 'Topic', 'topic', 30, 200, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('af5928f8-221a-4ac6-9acb-06dcfe278600', '3d4c0596-4d81-4dbd-ab02-cc9679a74705', 'Payload', 'payload', 30, 200, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('c09f122e-fb3d-4f7d-8430-c251d786b655', '3d4c0596-4d81-4dbd-ab02-cc9679a74705', 'Partition', 'partition', 3, 0, '0', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('f600f96a-33a3-459a-91de-396e078d4090', '3d4c0596-4d81-4dbd-ab02-cc9679a74705', 'Offset', 'offset', 4, 0, '0', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('1a4ebdc3-ea98-3c8d-9b88-31320ab525e4', '3d4c0596-4d81-4dbd-ab02-cc9679a74705', 'changedDate', 'changeddate', 20, 0, '', false);
INSERT INTO "mendixsystem$index" ("id", "table_id", "index_name") VALUES ('8f2298fe-f7ab-4238-bf91-56d263eedab3', '3d4c0596-4d81-4dbd-ab02-cc9679a74705', 'idx_tests$message_changeddate_asc');
INSERT INTO "mendixsystem$index_column" ("index_id", "column_id", "sort_order", "ordinal") VALUES ('8f2298fe-f7ab-4238-bf91-56d263eedab3', '1a4ebdc3-ea98-3c8d-9b88-31320ab525e4', false, 0);
INSERT INTO "mendixsystem$index" ("id", "table_id", "index_name") VALUES ('717a60a0-f518-4131-9cf1-dd24bcb7d500', '3d4c0596-4d81-4dbd-ab02-cc9679a74705', 'idx_tests$message_reference_asc');
INSERT INTO "mendixsystem$index_column" ("index_id", "column_id", "sort_order", "ordinal") VALUES ('717a60a0-f518-4131-9cf1-dd24bcb7d500', 'e90bf2ef-1ebf-4dc5-b464-24a8c9fc9e39', false, 0);
CREATE TABLE "unittesting$exceptionactivity" (
	"id" BIGINT NOT NULL,
	"stacktrace" VARCHAR_IGNORECASE(2147483647) NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", "entity_name", "table_name", "superentity_id", "remote", "remote_primary_key") VALUES ('98ab71e2-530c-422d-b561-7c8290c95969', 'UnitTesting.ExceptionActivity', 'unittesting$exceptionactivity', '9985e0a6-55b9-45d8-bf2f-39236459e6a1', false, false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('1b00e7d0-bbc9-4cfd-8477-aaff856a8ee0', '98ab71e2-530c-422d-b561-7c8290c95969', 'StackTrace', 'stacktrace', 30, 0, '', false);
CREATE TABLE "unittesting$unittest" (
	"id" BIGINT NOT NULL,
	"name" VARCHAR_IGNORECASE(511) NULL,
	"displayname" VARCHAR_IGNORECASE(255) NULL,
	"result" VARCHAR_IGNORECASE(10) NULL,
	"resultmessage" VARCHAR_IGNORECASE(2147483647) NULL,
	"stacktrace" VARCHAR_IGNORECASE(2147483647) NULL,
	"laststep" VARCHAR_IGNORECASE(2147483647) NULL,
	"lastrun" TIMESTAMP NULL,
	"ismf" BOOLEAN NULL,
	"readabletime" VARCHAR_IGNORECASE(300) NULL,
	"_dirty" BOOLEAN NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", "entity_name", "table_name", "remote", "remote_primary_key") VALUES ('a62164ad-835d-44c5-a4cc-6a7ec64d8508', 'UnitTesting.UnitTest', 'unittesting$unittest', false, false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('fd878df9-23ff-4e8a-8335-ab3a11a0673a', 'a62164ad-835d-44c5-a4cc-6a7ec64d8508', 'Name', 'name', 30, 511, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('1f3db913-f203-4e1f-8819-c0776da8601a', 'a62164ad-835d-44c5-a4cc-6a7ec64d8508', 'DisplayName', 'displayname', 30, 255, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('2d299873-ab89-4ecd-b33a-67fa133d738c', 'a62164ad-835d-44c5-a4cc-6a7ec64d8508', 'Result', 'result', 40, 10, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('a90423f6-1db1-4ee2-b55f-79562551acc0', 'a62164ad-835d-44c5-a4cc-6a7ec64d8508', 'ResultMessage', 'resultmessage', 30, 0, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('a7b5db3f-9f57-4759-8570-be3beb900a98', 'a62164ad-835d-44c5-a4cc-6a7ec64d8508', 'StackTrace', 'stacktrace', 30, 0, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('a59d3b8b-f1dc-4c9f-bea1-0b48f6e5e41c', 'a62164ad-835d-44c5-a4cc-6a7ec64d8508', 'LastStep', 'laststep', 30, 0, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('0eb767d3-9d81-417c-b2b9-b6c549220b3f', 'a62164ad-835d-44c5-a4cc-6a7ec64d8508', 'LastRun', 'lastrun', 20, 0, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('0e807424-e258-42fe-9b88-0c7c7072bd02', 'a62164ad-835d-44c5-a4cc-6a7ec64d8508', 'IsMf', 'ismf', 10, 0, 'false', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('4ff44660-d5f4-40d4-bc64-0baad1cf3175', 'a62164ad-835d-44c5-a4cc-6a7ec64d8508', 'ReadableTime', 'readabletime', 30, 300, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('b80b7ecc-6b3d-416a-be96-7c4a19f9db25', 'a62164ad-835d-44c5-a4cc-6a7ec64d8508', '_dirty', '_dirty', 10, 0, 'false', false);
CREATE TABLE "unittesting$startactivity" (
	"id" BIGINT NOT NULL,
	"result" VARCHAR_IGNORECASE(10) NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", "entity_name", "table_name", "superentity_id", "remote", "remote_primary_key") VALUES ('3ae001b2-27b7-4859-95f5-abaa59f07f95', 'UnitTesting.StartActivity', 'unittesting$startactivity', '9985e0a6-55b9-45d8-bf2f-39236459e6a1', false, false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('a66b80db-a6c8-46aa-9a94-2d8a7a0037e2', '3ae001b2-27b7-4859-95f5-abaa59f07f95', 'Result', 'result', 40, 10, '', false);
CREATE TABLE "unittesting$testactivity" (
	"id" BIGINT NOT NULL,
	"sequence" INT NULL,
	"message" VARCHAR_IGNORECASE(2147483647) NULL,
	"submetaobjectname" VARCHAR_IGNORECASE(255) NULL,
	PRIMARY KEY("id"));
CREATE INDEX "idx_unittesting$testactivity_submetaobjectname_asc" ON "unittesting$testactivity" ("submetaobjectname" ASC,"id" ASC);
INSERT INTO "mendixsystem$entity" ("id", "entity_name", "table_name", "remote", "remote_primary_key") VALUES ('9985e0a6-55b9-45d8-bf2f-39236459e6a1', 'UnitTesting.TestActivity', 'unittesting$testactivity', false, false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('6cd39897-5400-4061-81d8-3d79e42e88f7', '9985e0a6-55b9-45d8-bf2f-39236459e6a1', 'Sequence', 'sequence', 3, 0, '0', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('f907b219-37ec-4e59-95f4-693c9e23f1bb', '9985e0a6-55b9-45d8-bf2f-39236459e6a1', 'Message', 'message', 30, 0, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('1cfa7eee-7252-3ad2-bdaf-3d39a016d46d', '9985e0a6-55b9-45d8-bf2f-39236459e6a1', 'submetaobjectname', 'submetaobjectname', 30, 255, 'UnitTesting.TestActivity', false);
INSERT INTO "mendixsystem$index" ("id", "table_id", "index_name") VALUES ('172498dd-fe36-3759-911e-761215032973', '9985e0a6-55b9-45d8-bf2f-39236459e6a1', 'idx_unittesting$testactivity_submetaobjectname_asc');
INSERT INTO "mendixsystem$index_column" ("index_id", "column_id", "sort_order", "ordinal") VALUES ('172498dd-fe36-3759-911e-761215032973', '1cfa7eee-7252-3ad2-bdaf-3d39a016d46d', false, 0);
CREATE TABLE "tests$header_message" (
	"tests$headerid" BIGINT NOT NULL,
	"tests$messageid" BIGINT NOT NULL,
	PRIMARY KEY("tests$headerid","tests$messageid"),
	CONSTRAINT "uniq_tests$header_message_tests$headerid" UNIQUE ("tests$headerid"));
CREATE INDEX "idx_tests$header_message_tests$message_tests$header" ON "tests$header_message" ("tests$messageid" ASC,"tests$headerid" ASC);
INSERT INTO "mendixsystem$association" ("id", "association_name", "table_name", "parent_entity_id", "child_entity_id", "parent_column_name", "child_column_name", "index_name", "storage_format") VALUES ('ed888f6b-ff9a-4f07-a43c-2569c46a4aea', 'Tests.Header_Message', 'tests$header_message', 'd6d76584-9f48-4e54-8978-9ed65a973fbe', '3d4c0596-4d81-4dbd-ab02-cc9679a74705', 'tests$headerid', 'tests$messageid', 'idx_tests$header_message_tests$message_tests$header', 2);
INSERT INTO "mendixsystem$unique_constraint" ("name", "table_id", "column_id") VALUES ('uniq_tests$header_message_tests$headerid', 'ed888f6b-ff9a-4f07-a43c-2569c46a4aea', 'd10903f6-d2c4-328e-a1f0-c2bb64dab100');
CREATE TABLE "unittesting$unittest_testsuite" (
	"unittesting$unittestid" BIGINT NOT NULL,
	"unittesting$testsuiteid" BIGINT NOT NULL,
	PRIMARY KEY("unittesting$unittestid","unittesting$testsuiteid"),
	CONSTRAINT "uniq_unittesting$unittest_testsuite_unittesting$unittestid" UNIQUE ("unittesting$unittestid"));
CREATE INDEX "idx_unittesting$unittest_testsuite_unittesting$testsuite_unittesting$unittest" ON "unittesting$unittest_testsuite" ("unittesting$testsuiteid" ASC,"unittesting$unittestid" ASC);
INSERT INTO "mendixsystem$association" ("id", "association_name", "table_name", "parent_entity_id", "child_entity_id", "parent_column_name", "child_column_name", "index_name", "storage_format") VALUES ('d6c5d426-f3dc-4a2b-a5ef-321f9d45f2f7', 'UnitTesting.UnitTest_TestSuite', 'unittesting$unittest_testsuite', 'a62164ad-835d-44c5-a4cc-6a7ec64d8508', '496620d8-ac56-4268-be5f-922cab7c3481', 'unittesting$unittestid', 'unittesting$testsuiteid', 'idx_unittesting$unittest_testsuite_unittesting$testsuite_unittesting$unittest', 2);
INSERT INTO "mendixsystem$unique_constraint" ("name", "table_id", "column_id") VALUES ('uniq_unittesting$unittest_testsuite_unittesting$unittestid', 'd6c5d426-f3dc-4a2b-a5ef-321f9d45f2f7', '8c529047-715b-319a-b59b-521d56efa492');
CREATE TABLE "unittesting$testactivity_unittest" (
	"unittesting$testactivityid" BIGINT NOT NULL,
	"unittesting$unittestid" BIGINT NOT NULL,
	PRIMARY KEY("unittesting$testactivityid","unittesting$unittestid"),
	CONSTRAINT "uniq_unittesting$testactivity_unittest_unittesting$testactivityid" UNIQUE ("unittesting$testactivityid"));
CREATE INDEX "idx_unittesting$testactivity_unittest_unittesting$unittest_unittesting$testactivity" ON "unittesting$testactivity_unittest" ("unittesting$unittestid" ASC,"unittesting$testactivityid" ASC);
INSERT INTO "mendixsystem$association" ("id", "association_name", "table_name", "parent_entity_id", "child_entity_id", "parent_column_name", "child_column_name", "index_name", "storage_format") VALUES ('236154e8-f96e-4256-8385-e0e8101ab953', 'UnitTesting.TestActivity_UnitTest', 'unittesting$testactivity_unittest', '9985e0a6-55b9-45d8-bf2f-39236459e6a1', 'a62164ad-835d-44c5-a4cc-6a7ec64d8508', 'unittesting$testactivityid', 'unittesting$unittestid', 'idx_unittesting$testactivity_unittest_unittesting$unittest_unittesting$testactivity', 2);
INSERT INTO "mendixsystem$unique_constraint" ("name", "table_id", "column_id") VALUES ('uniq_unittesting$testactivity_unittest_unittesting$testactivityid', '236154e8-f96e-4256-8385-e0e8101ab953', 'd27b7f6d-5ccf-382a-894c-4fc69446ca7f');
UPDATE "mendixsystem$version" SET "versionnumber" = '4.2', "lastsyncdate" = '20260825 09:51:12';
