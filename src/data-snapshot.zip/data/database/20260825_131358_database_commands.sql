ALTER TABLE "kafka$consumer" ADD "contenttype" VARCHAR_IGNORECASE(6) NULL;
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('25099501-5abd-4185-9464-6920b3fc05e8', '9738a465-de2b-491e-9d56-1811a329c35f', 'ContentType', 'contenttype', 40, 6, '', false);
UPDATE "mendixsystem$version" SET "versionnumber" = '4.2', "lastsyncdate" = '20260825 13:13:58';
