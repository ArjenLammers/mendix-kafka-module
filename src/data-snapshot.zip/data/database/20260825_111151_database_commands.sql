CREATE TABLE "tests$binarypayload" (
	"id" BIGINT NOT NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", "entity_name", "table_name", "superentity_id", "remote", "remote_primary_key") VALUES ('c44513e7-01b8-4e11-87a0-963ea3efebe7', 'Tests.BinaryPayload', 'tests$binarypayload', '170ce49d-f29c-4fac-99a6-b55e8a3aeb39', false, false);
CREATE TABLE "tests$binarypayload_message" (
	"tests$binarypayloadid" BIGINT NOT NULL,
	"tests$messageid" BIGINT NOT NULL,
	PRIMARY KEY("tests$binarypayloadid","tests$messageid"),
	CONSTRAINT "uniq_tests$binarypayload_message_tests$messageid" UNIQUE ("tests$messageid"),
	CONSTRAINT "uniq_tests$binarypayload_message_tests$binarypayloadid" UNIQUE ("tests$binarypayloadid"));
CREATE INDEX "idx_tests$binarypayload_message_tests$message_tests$binarypayload" ON "tests$binarypayload_message" ("tests$messageid" ASC,"tests$binarypayloadid" ASC);
INSERT INTO "mendixsystem$association" ("id", "association_name", "table_name", "parent_entity_id", "child_entity_id", "parent_column_name", "child_column_name", "index_name", "storage_format") VALUES ('37a82e4e-83e4-4c5d-b812-c73d7b7c85e8', 'Tests.BinaryPayload_Message', 'tests$binarypayload_message', 'c44513e7-01b8-4e11-87a0-963ea3efebe7', '3d4c0596-4d81-4dbd-ab02-cc9679a74705', 'tests$binarypayloadid', 'tests$messageid', 'idx_tests$binarypayload_message_tests$message_tests$binarypayload', 2);
INSERT INTO "mendixsystem$unique_constraint" ("name", "table_id", "column_id") VALUES ('uniq_tests$binarypayload_message_tests$messageid', '37a82e4e-83e4-4c5d-b812-c73d7b7c85e8', 'f98e69eb-5b0c-3fb5-88e9-56c854809c74');
INSERT INTO "mendixsystem$unique_constraint" ("name", "table_id", "column_id") VALUES ('uniq_tests$binarypayload_message_tests$binarypayloadid', '37a82e4e-83e4-4c5d-b812-c73d7b7c85e8', '1110aa82-7e25-32c2-bbd7-c52d05d5cbf0');
UPDATE "mendixsystem$version" SET "versionnumber" = '4.2', "lastsyncdate" = '20260825 11:11:51';
