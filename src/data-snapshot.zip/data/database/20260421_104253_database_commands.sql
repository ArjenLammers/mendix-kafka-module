ALTER TABLE "kafka$server" ADD "useruntimecertificates" BOOLEAN NULL;
UPDATE "kafka$server" SET "useruntimecertificates" = false;
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('1f0d869b-5f98-4d2b-bd78-6382d22b8c26', 'd25372ca-d946-4bbd-85e7-30e30648b63b', 'UseRuntimeCertificates', 'useruntimecertificates', 10, 0, 'false', false);
UPDATE "mendixsystem$version" SET "versionnumber" = '4.2', "lastsyncdate" = '20260421 10:42:53';
